'''
Daisy Williams
Project 1
Hangman style game
'''

def main():

    #import modules
    #random - generate random number
    import random
    #re - work with regular expressions
    import re      

    #Introduction
    print("Welcome to our animal guessing game!\n")
    print("The object of the game is to guess the name of the animal. The word will have dashes " +
          "to indicate the amount of letters it contains. You will guess one letter at a time. For each correct letter you guess, " +
          "the dashes will be replaced with the corresponding letter. You will have 10 tries to guess each word.\n")

    #Menu Options
    def startGame():
        menuSelection = input("To begin the game enter 1. To quit, enter 2: ")
        if (str(menuSelection) == "1"):
            #test
            print ("You entered: " + str(menuSelection) + ". Let's begin!")

            #open and read text file
            with open("hangman.txt") as txt:
                wordList = txt.read().splitlines()

            #pick a random word 
            randomNumber = random.randint(0, len(wordList)-1)
            randomWord = wordList[randomNumber]

            #replace letters with dashes
            dashedWord = re.sub('[0-9a-zA-Z]', '-', randomWord)
            #test
            #print(randomWord)
            #print(dashedWord)

            #function for guessing
            def guess(letter, word, dashed):
                #check for letter
                letterFound = False
                if letter in word:
                    letterFound = True
                    #replace dashes with the correct letter
                    for i in range(0, len(word)):
                        if word[i] == letter:
                            dashed = dashed[0:i] + letter + dashed[i+1:len(dashed)]
                return (letterFound, dashed)


            #Start game
            #Show word with dashes and prompt for the player to make a guess
            numChances = 10
            print("\nYou have " + str(numChances) + " chances remaining.")
            print(dashedWord)

            while(numChances > 0):
                letterGuessed = input("Please guess a letter: ")[:1]
                print ("You guessed the letter: " + letterGuessed)

                letterFound, dashedWord = guess(letterGuessed, randomWord, dashedWord)

                if not letterFound:
                    numChances -= 1
                    if numChances == 0:
                        print("\nSorry, you ran out of chances. Game over! The word or phrase was: " + randomWord)
                        break
                    else:
                        print("\nThat letter was not found. You have " + str(numChances) + " chances remaining.")
                        print(dashedWord)
                else:
                    if "-" not in dashedWord:
                        print("\nGreat job, you won!")
                        playAgain = input("\nTo play again press 1. To exit, press 2: \n")
                        if (str(playAgain) == "1"):
                            startGame()
                        elif (str(playAgain) == "2"):
                            print("Goodbye!")
                        else:
                            print ("Invalid entry. Please enter 1 or 2: ")
                    else:
                        print("\nLetter found. Guess the next letter.")
                        print(dashedWord)
           
        elif (str(menuSelection) == "2"):
            print("Goodbye!")

        else:
            print ("Invalid entry. Please enter 1 or 2: ")
    startGame()

main()
